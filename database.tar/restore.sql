--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tontine;
--
-- Name: tontine; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE tontine WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE tontine OWNER TO admin;

\connect tontine

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO admin;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chi_tiet_hui; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chi_tiet_hui (
    id bigint NOT NULL,
    tham_keu bigint,
    ngay_khui date,
    ky integer,
    tien_hot bigint,
    hui_id bigint,
    hui_vien_id bigint,
    nick_name_hui_vien character varying(255)
);


ALTER TABLE public.chi_tiet_hui OWNER TO admin;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO admin;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO admin;

--
-- Name: hui; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.hui (
    id bigint NOT NULL,
    ten_hui character varying(255),
    ngay_tao date,
    loai_hui character varying(255),
    day_hui bigint,
    tham_keu bigint,
    so_phan integer
);


ALTER TABLE public.hui OWNER TO admin;

--
-- Name: hui_vien; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.hui_vien (
    id bigint NOT NULL,
    ho_ten character varying(255),
    sdt character varying(255)
);


ALTER TABLE public.hui_vien OWNER TO admin;

--
-- Name: jhi_authority; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jhi_authority (
    name character varying(50) NOT NULL
);


ALTER TABLE public.jhi_authority OWNER TO admin;

--
-- Name: jhi_user; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jhi_user (
    id bigint NOT NULL,
    login character varying(50) NOT NULL,
    password_hash character varying(60) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(191),
    image_url character varying(256),
    activated boolean NOT NULL,
    lang_key character varying(10),
    activation_key character varying(20),
    reset_key character varying(20),
    created_by character varying(50) NOT NULL,
    created_date timestamp without time zone,
    reset_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.jhi_user OWNER TO admin;

--
-- Name: jhi_user_authority; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jhi_user_authority (
    user_id bigint NOT NULL,
    authority_name character varying(50) NOT NULL
);


ALTER TABLE public.jhi_user_authority OWNER TO admin;

--
-- Name: sequence_generator; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.sequence_generator
    START WITH 1050
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sequence_generator OWNER TO admin;

--
-- Data for Name: chi_tiet_hui; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chi_tiet_hui (id, tham_keu, ngay_khui, ky, tien_hot, hui_id, hui_vien_id, nick_name_hui_vien) FROM stdin;
\.
COPY public.chi_tiet_hui (id, tham_keu, ngay_khui, ky, tien_hot, hui_id, hui_vien_id, nick_name_hui_vien) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
\.
COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM '$$PATH$$/3397.dat';

--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
\.
COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: hui; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.hui (id, ten_hui, ngay_tao, loai_hui, day_hui, tham_keu, so_phan) FROM stdin;
\.
COPY public.hui (id, ten_hui, ngay_tao, loai_hui, day_hui, tham_keu, so_phan) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: hui_vien; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.hui_vien (id, ho_ten, sdt) FROM stdin;
\.
COPY public.hui_vien (id, ho_ten, sdt) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: jhi_authority; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.jhi_authority (name) FROM stdin;
\.
COPY public.jhi_authority (name) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: jhi_user; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.jhi_user (id, login, password_hash, first_name, last_name, email, image_url, activated, lang_key, activation_key, reset_key, created_by, created_date, reset_date, last_modified_by, last_modified_date) FROM stdin;
\.
COPY public.jhi_user (id, login, password_hash, first_name, last_name, email, image_url, activated, lang_key, activation_key, reset_key, created_by, created_date, reset_date, last_modified_by, last_modified_date) FROM '$$PATH$$/3402.dat';

--
-- Data for Name: jhi_user_authority; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.jhi_user_authority (user_id, authority_name) FROM stdin;
\.
COPY public.jhi_user_authority (user_id, authority_name) FROM '$$PATH$$/3403.dat';

--
-- Name: sequence_generator; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.sequence_generator', 13550, true);


--
-- Name: chi_tiet_hui chi_tiet_hui_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chi_tiet_hui
    ADD CONSTRAINT chi_tiet_hui_pkey PRIMARY KEY (id);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: hui hui_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.hui
    ADD CONSTRAINT hui_pkey PRIMARY KEY (id);


--
-- Name: hui_vien hui_vien_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.hui_vien
    ADD CONSTRAINT hui_vien_pkey PRIMARY KEY (id);


--
-- Name: jhi_authority jhi_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jhi_authority
    ADD CONSTRAINT jhi_authority_pkey PRIMARY KEY (name);


--
-- Name: jhi_user_authority jhi_user_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jhi_user_authority
    ADD CONSTRAINT jhi_user_authority_pkey PRIMARY KEY (user_id, authority_name);


--
-- Name: jhi_user jhi_user_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jhi_user
    ADD CONSTRAINT jhi_user_pkey PRIMARY KEY (id);


--
-- Name: jhi_user ux_user_email; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jhi_user
    ADD CONSTRAINT ux_user_email UNIQUE (email);


--
-- Name: jhi_user ux_user_login; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jhi_user
    ADD CONSTRAINT ux_user_login UNIQUE (login);


--
-- Name: jhi_user_authority fk_authority_name; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jhi_user_authority
    ADD CONSTRAINT fk_authority_name FOREIGN KEY (authority_name) REFERENCES public.jhi_authority(name);


--
-- Name: chi_tiet_hui fk_chi_tiet_hui__hui_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chi_tiet_hui
    ADD CONSTRAINT fk_chi_tiet_hui__hui_id FOREIGN KEY (hui_id) REFERENCES public.hui(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chi_tiet_hui fk_chi_tiet_hui__hui_vien_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chi_tiet_hui
    ADD CONSTRAINT fk_chi_tiet_hui__hui_vien_id FOREIGN KEY (hui_vien_id) REFERENCES public.hui_vien(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: jhi_user_authority fk_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jhi_user_authority
    ADD CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES public.jhi_user(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: admin
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

